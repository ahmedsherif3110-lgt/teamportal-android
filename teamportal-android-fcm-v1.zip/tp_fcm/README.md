# Team Portal Android — نسخة الموقع

هذا التطبيق لا يعيد بناء الموقع. هو تطبيق Android خفيف يفتح نفس موقع Firebase مباشرة، لذلك أي تعديل على الموقع يظهر في التطبيق تلقائيًا.

## البناء بدون Android Studio

المشروع يحتوي Workflow لـ GitHub Actions. ارفع المجلد إلى GitHub ثم:
1. افتح تبويب Actions.
2. اختر Build Android APK.
3. اضغط Run workflow.
4. بعد انتهاء البناء، افتح Artifacts ونزّل `teamportal-apk`.

## الرابط الحالي
https://team-portal2027.web.app/

إذا تغيّر رابط الموقع، عدّل `siteUrl` داخل `MainActivity.kt`.
